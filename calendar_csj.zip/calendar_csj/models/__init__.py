# -*- coding: utf-8 -*-

from . import api_lifesize
from . import res_company
from . import res_partner
from . import calendar_appointment
from . import calendar_event
from . import calendar_recording_notification
from . import event

